// src/plugins/CodeBlockPlugin/icons/index.js
// Icons owned by CodeBlockPlugin. Registered into editor.ui.iconProvider at setup().
export default {
  codeblock: '<svg  width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 16 4-4-4-4"></path><path d="m6 8-4 4 4 4"></path><path d="m14.5 4-5 16"></path></svg>'
};
